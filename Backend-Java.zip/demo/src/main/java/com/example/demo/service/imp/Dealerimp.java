package com.example.demo.service.imp;

import com.example.demo.entity.Dealer;
import com.example.demo.repository.DealerRepositoty;
import com.example.demo.service.DealerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class Dealerimp implements DealerService {
    @Autowired
    private DealerRepositoty dealerRepositoty;


    @Override
    public List<Dealer> findAll() {
        return dealerRepositoty.findAll();
    }

    @Override
    public Dealer findById(int iddealer) {

 Dealer dealer= this.dealerRepositoty.findById(iddealer);
        return dealer;    }

    @Override
    public void create(Dealer dealer) {
        this.dealerRepositoty .save(dealer);

    }

    @Override
    public void update(Dealer dealer) {

        this.dealerRepositoty.save(dealer);
    }

    @Override
    public void delete(Dealer dealer) {

        this.dealerRepositoty.delete(dealer);
    }

}


