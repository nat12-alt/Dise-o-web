package com.example.demo.DTO;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDTO {

    private int iduser;
    private  String nameuser;
    private  String lastnameuser;
    private double Phoneuser;
    private  String emailuser;
    private  String addressuser;
    private Date dateofbirthuser;
    private String passworduser;
// llaves foraneas
    private CityDTO idcity;
    private RoleDTO idrole;


}
