package com.example.demo.business;


import com.example.demo.DTO.RequestDTO;
import com.example.demo.DTO.SaleDTO;
import com.example.demo.entity.Request;
import com.example.demo.entity.Sale;
import com.example.demo.service.RequestService;
import com.example.demo.service.SaleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class SaleBussines {
    @Autowired
    private SaleService saleService;
    @Autowired
    private RequestService requestService;

    private List<Sale> saleList;

    private List<SaleDTO> saleDTOList = new ArrayList<>();

    public List<SaleDTO> findAll() {
        this.saleList= this.saleService.findAll();
        this.saleList.stream().forEach(sale -> {
            SaleDTO saleDTO = new SaleDTO();
            saleDTO.setIdsale(sale.getIdsale());
            saleDTO.setDatesale(sale.getDatesale());
            saleDTO.setPricesale(sale.getPriceSale());

            //Foranea request

            Request request = sale.getIdrequest();
            if (request !=null) {
                RequestDTO requestDTO = new RequestDTO();
                requestDTO.setIdrequest(request.getIdrequest());
                saleDTO.setIdrequest(requestDTO);
            }


            saleDTOList.add(saleDTO);
        });
        return this.saleDTOList;
    }

    public Sale findById(int idsale) {
        return this.saleService.findById(idsale);
    }

    public void createSale(SaleDTO saleDTO) throws Exception {
        Sale sale= new Sale();
        //Concatenacion
        System.out.printf("@@"+saleDTO.toString());


        //Foranea Request
        RequestDTO requestDTO=saleDTO.getIdrequest();
        Request request= requestService.findById(requestDTO.getIdrequest());
        sale.setIdrequest(request);

        sale.setDatesale(saleDTO.getDatesale());
        sale.setPriceSale(saleDTO.getPricesale());

        this.saleService.create(sale);
    }

    public void updateSale (int id, SaleDTO updatedSaleDTO) throws Exception {
        Sale existingSale =saleService.findById(id);
        if (existingSale == null) {
            throw new Exception("Venta no encontrada!");
        }

        existingSale.setDatesale(updatedSaleDTO.getDatesale());
        existingSale.setPriceSale(updatedSaleDTO.getPricesale());

        //Foranea Request

        if (updatedSaleDTO.getIdrequest()!=null){
            int requestId=updatedSaleDTO.getIdrequest().getIdrequest();
            Request request=requestService.findById(requestId);
            if (request==null){
                throw  new Exception("El id"+requestId+"no se encuentra");

            }
            existingSale.setIdrequest(request);
        }


        this.saleService.update(existingSale);
    }

    public void deleteSale (int id) throws Exception{
        Sale existingSale = saleService.findById(id);
        if (existingSale == null) {
            throw new Exception("Venta no encontrada!");
        }

        this.saleService.delete(existingSale);
    }
}

