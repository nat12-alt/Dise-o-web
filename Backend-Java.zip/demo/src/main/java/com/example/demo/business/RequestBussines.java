package com.example.demo.business;

import com.example.demo.DTO.RequestDTO;
import com.example.demo.DTO.UserDTO;
import com.example.demo.entity.Request;
import com.example.demo.entity.User;
import com.example.demo.service.RequestService;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class RequestBussines {

    @Autowired
    private RequestService requestService;
    @Autowired
    private UserService userService;
    private List<Request> requestList;

    private List<RequestDTO> requestDTOList = new ArrayList<>();

    public List<RequestDTO> findAll() {
        this.requestList= this.requestService.findAll();
        this.requestList.stream().forEach(request -> {
            RequestDTO requestDTO = new RequestDTO();
            requestDTO.setIdrequest(request.getIdrequest());
            requestDTO.setDaterequest(request.getDaterequest());
            requestDTO.setStatusrequest(request.getStatusrequest());
            requestDTO.setValuerequest(request.getValuerequest());
            requestDTO.setTyperequest(request.getTyperequest());

         //Foranea User
            User user = request.getIduser();
            if (user !=null) {
                UserDTO userDTO = new UserDTO();
                userDTO.setIduser(user.getIduser());
                requestDTO.setIduser(userDTO);
            }



            requestDTOList.add(requestDTO);
        });
        return this.requestDTOList;
    }

    public Request findById(int idrequest) {
        return this.requestService.findById(idrequest);
    }

    public void createRequest(RequestDTO requestDTO) throws Exception {
        Request request = new Request();
        //Concatenacion
        System.out.printf("@@"+requestDTO.toString());


        //Foranea user
        UserDTO userDTO=requestDTO.getIduser();
        User user= userService.findById(userDTO.getIduser());
        request.setIduser(user);

        request.setDaterequest(requestDTO.getDaterequest());
        request.setStatusrequest(requestDTO.getStatusrequest());
        request.setValuerequest(requestDTO.getValuerequest());
        request.setTyperequest(requestDTO.getTyperequest());

        this.requestService.create(request);
    }

    public void updateRequest(int id, RequestDTO updatedRequestDTO) throws Exception {
        Request existingRequest = requestService.findById(id);
        if (existingRequest == null) {
            throw new Exception("Pedido no encontrado!");
        }

        existingRequest.setDaterequest(updatedRequestDTO.getDaterequest());
        existingRequest.setStatusrequest(updatedRequestDTO.getStatusrequest());
        existingRequest.setValuerequest(updatedRequestDTO.getValuerequest());
        existingRequest.setTyperequest(updatedRequestDTO.getTyperequest());

        //Foranea User

        if (updatedRequestDTO.getIduser()!=null){
            int userId=updatedRequestDTO.getIduser().getIduser();
            User user=userService.findById(userId);
            if (user==null){
                throw  new Exception("El id"+userId+"no se encuentra");

            }
            existingRequest.setIduser(user);
        }



        this.requestService.update(existingRequest);
    }

    public void deleteRequest(int id) throws Exception{
        Request existingRequest = requestService.findById(id);
        if (existingRequest == null) {
            throw new Exception("Pedido no encontrado!");
        }

        this.requestService.delete(existingRequest);
    }
}


