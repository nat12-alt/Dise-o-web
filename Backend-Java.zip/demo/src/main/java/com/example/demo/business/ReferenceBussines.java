package com.example.demo.business;


import com.example.demo.DTO.ReferenceDTO;
import com.example.demo.entity.Reference;

import com.example.demo.service.ReferenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class ReferenceBussines {

    @Autowired
    private ReferenceService referenceService;

    private List<Reference> referenceList;

    private List<ReferenceDTO> referenceDTOList = new ArrayList<>();

    public List<ReferenceDTO> findAll() {
        this.referenceList= this.referenceService.findAll();
        this.referenceList.stream().forEach(reference -> {
            ReferenceDTO referenceDTO = new ReferenceDTO();
            referenceDTO.setIdreference(reference.getIdreference());
            referenceDTO.setNamereference(reference.getNamereference());


            referenceDTOList.add(referenceDTO);
        });
        return this.referenceDTOList;
    }

    public Reference findById(int idreference) {
        return this.referenceService.findById(idreference);
    }

    public void createReference(ReferenceDTO referenceDTO) throws Exception {
        Reference reference = new Reference();
        //Concatenacion
        System.out.printf("@@"+referenceDTO.toString());


        reference.setNamereference(referenceDTO.getNamereference());

        this.referenceService.create(reference);
    }

    public void updateReference(int id, ReferenceDTO updatedReferenceDTO) throws Exception {
        Reference existingReference = referenceService.findById(id);
        if (existingReference == null) {
            throw new Exception("Referencia no encontrado!");
        }

        existingReference.setNamereference(updatedReferenceDTO.getNamereference());

        this.referenceService.update(existingReference);
    }

    public void deleteReference(int id) throws Exception{
        Reference existingReference = referenceService.findById(id);
        if (existingReference == null) {
            throw new Exception("Reference no encontrado!");
        }

        this.referenceService.delete(existingReference);
    }
}



