package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Entity
@Table (name = "products")
@Data
public class Product implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column (name = "idproduct")
    private  int idproduct ;

    @Column(name= "nameproduct", length = 30)
    private String nameProduct;
    @Column(name= "valueproduct")
    private Float valueProduct;
    @Column(name= "stockproduct", length = 11)
    private int stockProduct;

    //Relacion foranea
    @JsonManagedReference
    @ManyToOne
    @JoinColumn (name = "idcategory")
    private Category idcategory;

    //Relacion foranea
    @JsonBackReference
    @OneToMany (mappedBy = "idproduct")
    private List<DetailProduct> detailProductList;

    //Relacion ManyToMany para la tabla intermedia product_dealer
    @JsonManagedReference
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "product_dealer",
            joinColumns = @JoinColumn(name = "idproduct", nullable = false),
            inverseJoinColumns = @JoinColumn(name = "iddealer", nullable = false)
    )
    private List<Dealer> dealerList;

    //Relacion ManyToMany para la tabla intermedia sale_product
    @JsonBackReference
    @ManyToMany(mappedBy = "productList", fetch = FetchType.LAZY)
    private List<Sale> saleList;

}
