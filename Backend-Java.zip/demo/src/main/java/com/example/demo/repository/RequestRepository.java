package com.example.demo.repository;

import com.example.demo.entity.Request;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface RequestRepository extends JpaRepository <Request,Integer> {
    @Query(value = "SELECT rq FROM Request rq WHERE rq.idrequest=:idrequest")
    public Request findById (int idrequest);


}
