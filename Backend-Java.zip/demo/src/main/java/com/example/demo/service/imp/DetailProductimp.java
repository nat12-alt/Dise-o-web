package com.example.demo.service.imp;

import com.example.demo.entity.DetailProduct;
import com.example.demo.repository.DetailProductRepository;
import com.example.demo.service.DetailProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public  class DetailProductimp implements DetailProductService {

    @Autowired
    private DetailProductRepository detailProductRepository;


    @Override
    public List<DetailProduct> findAll() {
        return detailProductRepository.findAll();
    }

    @Override
    public DetailProduct findById(int iddetailproduct) {

        DetailProduct detailProduct= this.detailProductRepository.findById(iddetailproduct);
        return detailProduct;
    }

    @Override
    public void create(DetailProduct detailProduct) {
        this.detailProductRepository .save(detailProduct);

    }

    @Override
    public void update(DetailProduct detailProduct) {

        this.detailProductRepository.save(detailProduct);
    }

    @Override
    public void delete(DetailProduct detailProduct) {

        this.detailProductRepository.delete(detailProduct);
    }
}
