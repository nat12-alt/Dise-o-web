package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.sql.Date;

@Entity
@Table(name = "detailproduct")
@Data


public class DetailProduct implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column (name = "iddetailproduct")
    private  int iddetailproduct;

    @Column(name= "entrycount", length = 11)
    private int entrycount;

    @Column(name= "entrydate")
    private Date entrydate;

    @Column(name= "exittype", length = 11)
    private String exittype;

    @Column(name= "exitdate")
    private Date exitdate;

    @Column(name= "exitcount", length = 11)
    private int exitcount;



    //Foranea Sale
    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name = "idsale")
    private Sale idsale;

   //Foranea Product
    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name = "idproduct")
    private Product idproduct;

}
