package com.example.demo.business;


import com.example.demo.DTO.SizeDTO;
import com.example.demo.entity.Size;
import com.example.demo.service.SizeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class SizeBusiness {

    @Autowired
    private SizeService sizeService;

    private List<Size> sizeList;

    private List<SizeDTO> sizeDTOList = new ArrayList<>();

    public List<SizeDTO> findAll() {
        this.sizeList= this.sizeService.findAll();
        this.sizeList.stream().forEach(size -> {
            SizeDTO sizeDTO = new SizeDTO();
            sizeDTO.setIdsize(size.getIdsize());
            sizeDTO.setNumsize(size.getNumsize());
            sizeDTO.setLetersize(size.getLetersize());



            sizeDTOList.add(sizeDTO);
        });
        return this.sizeDTOList;
    }

    public Size findById(int idsize) {
        return this.sizeService.findById(idsize);
    }



}