package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "citys")
@Data


public class City implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column (name = "idcity")
    private  int idcity;

    @Column(name= "namecity", length = 11)
    private String namecity;

    //Relacion llave foranea
    @JsonBackReference
    @OneToMany (mappedBy = "idcity")
    private List<User> userList;


}
