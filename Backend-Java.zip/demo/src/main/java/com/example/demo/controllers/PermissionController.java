package com.example.demo.controllers;

import com.example.demo.DTO.PermissionDTO;
import com.example.demo.business.PermissionBussines;
import com.example.demo.entity.Permission;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Permission",method = {RequestMethod.GET,RequestMethod.PUT,RequestMethod.POST})
@CrossOrigin("*")
public class PermissionController {

    @Autowired
    private PermissionBussines permissionBussines;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllPermission() {
        Map<String, Object> res = new HashMap<>();
        List<PermissionDTO> listPermission= this.permissionBussines.findAll();
        res.put("status", "success");
        res.put("data", listPermission);

        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getPermissionById(@PathVariable int id) {
        try {
            Permission data = permissionBussines.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("status", "success");
            response.put("data", data);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("status", "error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
    }


    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createPermission(@RequestBody PermissionDTO newPermission) {
        Map<String, Object> res = new HashMap<>();

        try {
            permissionBussines.createPermission(newPermission);
            res.put("status", "success");
            res.put("data", newPermission);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updatePermission(@PathVariable int id, @RequestBody PermissionDTO existingPermission) {
        Map<String, Object> res = new HashMap<>();
        try {
            permissionBussines.updatePermission(id, existingPermission);
            res.put("status", "success");
            res.put("data", existingPermission);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
