package com.example.demo.controllers;


import com.example.demo.DTO.ReferenceDTO;
import com.example.demo.business.ReferenceBussines;
import com.example.demo.entity.Reference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Reference", method = { RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST })
@CrossOrigin("*")
public class ReferenceController {
  @Autowired
    private ReferenceBussines  referenceBussines;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllReference() {
        Map<String, Object> res = new HashMap<>();
        List<ReferenceDTO> listReference= this.referenceBussines.findAll();
        res.put("status", "success");
        res.put("data", listReference);

        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getReferenceById(@PathVariable int id) {
        try {
            Reference data = referenceBussines.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("status", "success");
            response.put("data", data);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("status", "error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createReference(@RequestBody  ReferenceDTO newReference) {
        Map<String, Object> res = new HashMap<>();

        try {
            referenceBussines.createReference(newReference);
            res.put("status", "success");
            res.put("data", newReference);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.OK);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateReference(@PathVariable int id, @RequestBody ReferenceDTO existingReference) {
        Map<String, Object> res = new HashMap<>();
        try {
            referenceBussines.updateReference(id, existingReference);
            res.put("status", "success");
            res.put("data", existingReference);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteReference(@PathVariable int id) {
        Map<String, Object> res = new HashMap<>();
        try {
            referenceBussines.deleteReference(id);
            res.put("status", "success");
            res.put("message", "Reference deleted successfully");
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
