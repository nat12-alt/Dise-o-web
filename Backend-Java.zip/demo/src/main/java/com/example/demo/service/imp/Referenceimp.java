package com.example.demo.service.imp;

import com.example.demo.entity.Reference;
import com.example.demo.repository.ReferenceRepository;
import com.example.demo.service.ReferenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public  class Referenceimp implements ReferenceService {
    @Autowired
    private ReferenceRepository referenceRepository;


    @Override
    public List<Reference> findAll() {
        return this.referenceRepository.findAll();
    }
    @Override
    public Reference findById(int idreference) {

        Reference reference= this.referenceRepository.findById(idreference);
        return reference;
    }


    @Override
    public void create(Reference reference) {
        this.referenceRepository.save(reference);
    }

    @Override
    public void update(Reference reference) {
        this.referenceRepository.save(reference);

    }

    @Override
    public void delete(Reference reference) {
        this.referenceRepository.delete(reference);

    }



}
