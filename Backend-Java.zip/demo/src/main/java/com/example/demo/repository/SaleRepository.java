package com.example.demo.repository;
import com.example.demo.entity.Sale;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



@Repository
public interface SaleRepository extends JpaRepository<Sale,Integer> {
    @Query(value = "SELECT sl FROM Sale sl WHERE sl.idsale=:idsale")
    public Sale findById(int idsale);

}
