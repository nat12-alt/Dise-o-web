package com.example.demo.service.imp;

import com.example.demo.entity.Request;
import com.example.demo.repository.RequestRepository;
import com.example.demo.service.RequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Requestimp implements RequestService {
    @Autowired
    private RequestRepository requestRepository;


    @Override
    public List<Request> findAll() {
        return this.requestRepository.findAll();

    }
    @Override
    public Request findById(int idrequest) {

        Request request= this.requestRepository.findById(idrequest);
        return request;
    }


    @Override
    public void create(Request request) {
        this.requestRepository.save(request);
    }

    @Override
    public void update(Request request) {
        this.requestRepository.save(request);

    }

    @Override
    public void delete(Request request) {
        this.requestRepository.delete(request);

    }



    }


