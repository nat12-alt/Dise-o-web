package com.example.demo.service;

import com.example.demo.entity.Reference;


import java.util.List;

public interface ReferenceService {
    public List<Reference> findAll() ;
    public Reference findById (int idreference);

    public void create (Reference reference);
    public void update (Reference reference);

    public void delete (Reference reference);



}
