package com.example.demo.controllers;

import com.example.demo.DTO.DealerDTO;
import com.example.demo.business.DealerBussines;
import com.example.demo.entity.Dealer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Dealer",method = {RequestMethod.GET,RequestMethod.PUT,RequestMethod.POST})
@CrossOrigin("*")
public class DealerController {
    @Autowired
    private DealerBussines dealerBussines;

    @GetMapping("/all")
    public ResponseEntity<Map<String,Object>> findAllDealer() throws Exception {
        Map<String, Object> res = new HashMap<>();
        List<DealerDTO> listDealerDTO= this.dealerBussines.findAll();
        res.put( "status", "success");
        res.put("data", listDealerDTO);

        return new ResponseEntity<>(res, HttpStatus.OK);

    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getDealerById(@PathVariable int id) {
        try {
            Dealer data = dealerBussines.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("status", "success");
            response.put("data", data);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("status", "error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @PostMapping ("/create")
    public ResponseEntity<Map<String,Object>>createDealer(@RequestBody DealerDTO newDealer) {
        Map<String, Object> response = new HashMap<>();

        try {
             dealerBussines.createDealer (newDealer);
            response.put("status", "Succes");
            response.put("data",newDealer);
            return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("massage", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.OK);
        }

}
    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateDealer(@PathVariable int id, @RequestBody DealerDTO existingDealer) {
        Map<String, Object> res = new HashMap<>();
        try {
            dealerBussines.updateDealer(id,existingDealer);
            res.put("status", "success");
            res.put("data", existingDealer);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteDealer(@PathVariable int id) {
        Map<String, Object> res = new HashMap<>();
        try {
            dealerBussines.deleteDealer(id);
            res.put("status", "success");
            res.put("message", "Dealer deleted successfully");
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}



