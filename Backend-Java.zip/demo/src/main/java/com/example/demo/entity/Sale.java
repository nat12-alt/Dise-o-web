package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

@Entity
@Table (name = "sales")
@Data


public class Sale implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column (name = "idsale")
    private int idsale;

    @Column(name= "datesale")
    private Date Datesale;
    @Column(name= "pricesale")
    private BigDecimal priceSale;

   //Foranea Request
    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name = "idrequest")
    private Request idrequest ;

    //Foranea de Sale en DetailProduct
    @JsonBackReference
    @OneToMany (mappedBy = "idsale")
    private List<DetailProduct> detailProductList;
    //Foranea ManyToMany para sale_product
    @JsonManagedReference
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "sale_product",
        joinColumns = @JoinColumn(name = "idsale", nullable = false),
        inverseJoinColumns = @JoinColumn(name = "idproduct", nullable = false)
)
private List<Product> productList;
}
