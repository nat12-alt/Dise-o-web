package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;

@Entity
@Table(name = "categorys")
@Data
public class Category implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idcategory")
    private int idcategory;

    @Column(name = "namecategory", length = 11)
    private String namecategory;

    @Column(name = "desccategory")
    private String desccategory;

  //Foranea References
  @JsonManagedReference
  @ManyToOne
  @JoinColumn(name = "idreference")
  private Reference idreference;
  //Forane Size
  @JsonManagedReference
  @ManyToOne
  @JoinColumn(name = "idsize")
  private Size idsize;
}