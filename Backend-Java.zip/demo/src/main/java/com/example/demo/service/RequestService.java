package com.example.demo.service;

import com.example.demo.entity.Request;

import java.util.List;

public interface RequestService {
    public List<Request> findAll() ;

    public Request findById (int idrequest);
    public void create (Request request);
    public void update (Request request);

    public void delete (Request request);


}
