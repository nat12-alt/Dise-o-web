package com.example.demo.service;

import com.example.demo.entity.City;


import java.util.List;

public interface CityService {
    public List<City> findAll ();
    public City findById (int idcity);
    public void create ( City city);
    public void  update (City city);
    public void delete (City city);


}
