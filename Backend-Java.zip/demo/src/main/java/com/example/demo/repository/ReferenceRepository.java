package com.example.demo.repository;


import com.example.demo.entity.Reference;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ReferenceRepository extends JpaRepository<Reference,Integer> {
    @Query(value = "SELECT rf FROM Reference rf WHERE rf.idreference=:idreference")
    public Reference findById (int idreference);


}
