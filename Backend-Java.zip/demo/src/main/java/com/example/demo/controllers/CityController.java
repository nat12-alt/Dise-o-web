package com.example.demo.controllers;

import com.example.demo.DTO.CityDTO;
import com.example.demo.business.CityBussines;
import com.example.demo.entity.City;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;



@RestController
@RequestMapping(path = "/api/City", method = { RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST })
@CrossOrigin("*")
public class CityController {
    @Autowired
    private CityBussines cityBussines;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllCity() {
        Map<String, Object> res = new HashMap<>();
        List<CityDTO> listCity= this.cityBussines.findAll();
        res.put("status", "success");
        res.put("data", listCity);

        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getCityById(@PathVariable int id) {
        try {
            City data = cityBussines.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("status", "success");
            response.put("data", data);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("status", "error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createCity(@RequestBody  CityDTO newCity) {
        Map<String, Object> res = new HashMap<>();

        try {
            cityBussines.createCity(newCity);
            res.put("status", "success");
            res.put("data", newCity);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.OK);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateCity(@PathVariable int id, @RequestBody CityDTO existingCity) {
        Map<String, Object> res = new HashMap<>();
        try {
            cityBussines.updateCity(id, existingCity);
            res.put("status", "success");
            res.put("data", existingCity);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteCity(@PathVariable int id) {
        Map<String, Object> res = new HashMap<>();
        try {
            cityBussines.deleteCity(id);
            res.put("status", "success");
            res.put("message", "Buy deleted successfully");
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
