 package com.example.demo.controllers;


 import com.example.demo.DTO.SaleDTO;
 import com.example.demo.business.SaleBussines;
 import com.example.demo.entity.Sale;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.http.HttpStatus;
 import org.springframework.http.ResponseEntity;
 import org.springframework.web.bind.annotation.*;

 import java.util.HashMap;
 import java.util.List;
 import java.util.Map;

 @RestController
 @RequestMapping(path = "/api/Sale", method = { RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST })
 @CrossOrigin("*")
public class SaleController {

    @Autowired
    private SaleBussines saleBussines;


     @GetMapping("/all")
     public ResponseEntity<Map<String, Object>> findAllSale() {
         Map<String, Object> res = new HashMap<>();
         List<SaleDTO> listSale = this.saleBussines.findAll();
         res.put("status", "success");
         res.put("data", listSale);

         return new ResponseEntity<>(res, HttpStatus.OK);
     }

     @GetMapping("/all/{id}")
     public ResponseEntity<Map<String, Object>> getSaleById(@PathVariable int id) {
         try {
             Sale data = saleBussines.findById(id);
             Map<String, Object> response = new HashMap<>();
             response.put("status", "success");
             response.put("data", data);
             return new ResponseEntity<>(response, HttpStatus.OK);
         } catch (Exception e) {
             Map<String, Object> response = new HashMap<>();
             response.put("status", "error");
             response.put("message", e.getMessage());
             return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
         }
     }

     @PostMapping("/create")
     public ResponseEntity<Map<String, Object>> createSale(@RequestBody  SaleDTO newSale) {
         Map<String, Object> res = new HashMap<>();

         try {
             saleBussines.createSale(newSale);
             res.put("status", "success");
             res.put("data", newSale);
             return new ResponseEntity<>(res, HttpStatus.CREATED);
         } catch (Exception e) {
             res.put("status", "error");
             res.put("message", e.getMessage());
             return new ResponseEntity<>(res, HttpStatus.OK);
         }
     }

     @PutMapping("/update/{id}")
     public ResponseEntity<Map<String, Object>> updateSale(@PathVariable int id, @RequestBody SaleDTO existingSale) {
         Map<String, Object> res = new HashMap<>();
         try {
             saleBussines.updateSale(id, existingSale);
             res.put("status", "success");
             res.put("data", existingSale);
             return new ResponseEntity<>(res, HttpStatus.OK);
         } catch (Exception e) {
             res.put("status", "error");
             res.put("message", e.getMessage());
             return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
         }
     }

     @DeleteMapping("/delete/{id}")
     public ResponseEntity<Map<String, Object>> deleteSale(@PathVariable int id) {
         Map<String, Object> res = new HashMap<>();
         try {
             saleBussines.deleteSale(id);
             res.put("status", "success");
             res.put("message", "Sale deleted successfully");
             return new ResponseEntity<>(res, HttpStatus.OK);
         } catch (Exception e) {
             res.put("status", "error");
             res.put("message", e.getMessage());
             return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
         }
     }
 }