package com.example.demo.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RequestDTO {
    private int idrequest;
    private Date daterequest;
    private  String typerequest;
    private  String statusrequest;
    private  float valuerequest;
    //Llave foranea
    private UserDTO iduser;






}
