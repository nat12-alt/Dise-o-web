package com.example.demo.service;

import com.example.demo.entity.Sale;


import java.util.List;

public interface SaleService {
    public  List<Sale> findAll();
    public Sale findById (int idsale);
    public void create(Sale sale);
    public void update(Sale sale);

    public  void delete(Sale sale);


}
