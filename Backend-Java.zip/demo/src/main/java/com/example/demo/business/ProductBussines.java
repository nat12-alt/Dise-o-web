package com.example.demo.business;


import com.example.demo.DTO.CategoryDTO;
import com.example.demo.DTO.ProductDTO;
import com.example.demo.entity.Category;
import com.example.demo.entity.Product;
import com.example.demo.service.CategoryService;
import com.example.demo.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component

public class ProductBussines {
    @Autowired
    private ProductService productService;

    @Autowired
    private CategoryService categoryService;

    private List<Product> productList;

    private List<ProductDTO> productDTOList = new ArrayList<>();

    public List<ProductDTO> findAll() {
        this.productList= this.productService.findAll();
        this.productList.stream().forEach(product -> {
            ProductDTO productDTO = new ProductDTO();
            productDTO.setIdproduct(product.getIdproduct());
            productDTO.setNameproduct(product.getNameProduct());
            productDTO.setValueproduct(product.getValueProduct());
            productDTO.setStockproduct(product.getStockProduct());

            //Foranea Category

            Category category =product.getIdcategory();
            if (category !=null) {
                CategoryDTO categoryDTO = new CategoryDTO();
                categoryDTO.setIdcategory(category.getIdcategory());
                productDTO.setIdcategory(categoryDTO);

            }

            productDTOList.add(productDTO);
        });
        return this.productDTOList;
    }

    public Product findById(int idProduct) {

        return this.productService.findById(idProduct);
    }

    public void createProduct(ProductDTO productDTO) throws Exception {
        Product product = new Product();
        //Concatenacion
        System.out.printf("@@"+productDTO.toString());


        //Foranea Category
        CategoryDTO categoryDTO=productDTO.getIdcategory();
        Category category= categoryService.findById(categoryDTO.getIdcategory());
        product.setIdcategory(category);

        product.setNameProduct(productDTO.getNameproduct());
        product.setValueProduct(productDTO.getValueproduct());
        product.setStockProduct(productDTO.getStockproduct());

        this.productService.create(product);
    }

    public void updateProduct(int id, ProductDTO updatedProductDTO) throws Exception {
        Product existingProduct = productService.findById(id);
        if (existingProduct == null) {
            throw new Exception("Producto no encontrado!");
        }

        existingProduct.setNameProduct(updatedProductDTO.getNameproduct());
        existingProduct.setValueProduct(updatedProductDTO.getValueproduct());
        existingProduct.setStockProduct(updatedProductDTO.getStockproduct());

        //Foranea Category
        if (updatedProductDTO.getIdcategory()!=null){
            int categoryId=updatedProductDTO.getIdcategory().getIdcategory();
            Category category=categoryService.findById(categoryId);
            if (category==null){
                throw  new Exception("El id"+categoryId+"no se encuentra");

            }
            existingProduct.setIdcategory(category);
        }

        this.productService.update(existingProduct);
    }

    public void deleteProduct(int id) throws Exception{
        Product existingProduct= productService.findById(id);
        if (existingProduct == null) {
            throw new Exception("Producto no encontrado!");
        }

        this.productService.delete(existingProduct);
    }
}


