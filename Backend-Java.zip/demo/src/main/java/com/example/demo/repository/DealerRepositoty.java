package com.example.demo.repository;



import com.example.demo.entity.Dealer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface DealerRepositoty extends JpaRepository<Dealer,Integer> {
    @Query(value = "SELECT d FROM Dealer d WHERE d.iddealer=:iddealer")
    public Dealer findById (int iddealer);
}
