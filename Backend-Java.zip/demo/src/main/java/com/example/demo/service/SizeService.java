package com.example.demo.service;


import com.example.demo.entity.Size;


import java.util.List;

public interface SizeService {
    public  List<Size> findAll() ;

    Size findById(int idsize);




}
