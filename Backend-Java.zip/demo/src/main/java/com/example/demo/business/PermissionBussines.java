package com.example.demo.business;

import com.example.demo.DTO.PermissionDTO;
import com.example.demo.entity.Permission;
import com.example.demo.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class PermissionBussines {

    @Autowired
    private PermissionService permissionService;

    private List<Permission> permissionList;

    private List<PermissionDTO> permissionDTOList = new ArrayList<>();

    public List<PermissionDTO> findAll() {
        this.permissionList= this.permissionService.findAll();
        this.permissionList.stream().forEach(permission -> {
            PermissionDTO permissionDTO = new PermissionDTO();
            permissionDTO.setIdpermission(permission.getIdpermission());
            permissionDTO.setTypepermission(permission.getTypepermission());


            permissionDTOList.add(permissionDTO);
        });
        return this.permissionDTOList;
    }

    public Permission findById(int idpermission) {
        return this.permissionService.findById(idpermission);
    }

    public void createPermission(PermissionDTO permissionDTO) throws Exception {
        Permission permission = new Permission();
        //Concatenacion
        System.out.printf("@@"+permissionDTO.toString());

        permission.setTypepermission(permissionDTO.getTypepermission());

        this.permissionService.create(permission);
    }
    public void updatePermission(int id, PermissionDTO updatePermissionDTO) throws Exception {
        Permission existingPermission = permissionService.findById(id);
        if (existingPermission == null) {
            throw new Exception("City no encontrado!");
        }

        existingPermission.setTypepermission(updatePermissionDTO.getTypepermission());

        this.permissionService.update(existingPermission);
    }

}
