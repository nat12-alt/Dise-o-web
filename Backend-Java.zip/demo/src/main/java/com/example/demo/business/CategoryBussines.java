package com.example.demo.business;

import com.example.demo.DTO.*;
import com.example.demo.entity.*;
import com.example.demo.service.CategoryService;
import com.example.demo.service.ReferenceService;
import com.example.demo.service.SizeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
@Component
public class CategoryBussines {
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private ReferenceService referenceService;
    @Autowired
    private SizeService sizeService;
    private List<Category> categoryList;

    private List<CategoryDTO> categotyDTOList = new ArrayList<>();

    public List<CategoryDTO> findAll() {
        this.categoryList= this.categoryService.findAll();
        this.categoryList.stream().forEach(category -> {
            CategoryDTO categoryDTO = new CategoryDTO();
            categoryDTO.setIdcategory(category.getIdcategory());
            categoryDTO.setNamecategory(category.getNamecategory());
            categoryDTO.setDescategory(category.getDesccategory());
//Foranea Reference
            Reference reference =category.getIdreference();
            if (reference !=null){
                ReferenceDTO referenceDTO = new ReferenceDTO();
                referenceDTO.setIdreference(reference.getIdreference());
                categoryDTO.setIdreference(referenceDTO);
 //Foranea Size
                Size size =category.getIdsize();
                if ( size!=null){
                    SizeDTO sizeDTO = new SizeDTO();
                    sizeDTO.setIdsize(size.getIdsize());
                    categoryDTO.setIdsize(sizeDTO);
                }
            }


            categotyDTOList.add(categoryDTO);
        });
        return this.categotyDTOList;
    }

    public Category findById(int idcategory) {

        return this.categoryService.findById(idcategory);
    }

    public void createCategory (CategoryDTO categoryDTO) throws Exception {
        Category category = new Category();
        //Concatenacion
        System.out.printf("@@"+categoryDTO.toString());
//Foranea Reference
        ReferenceDTO referenceDTO=categoryDTO.getIdreference();
        Reference reference= referenceService.findById(referenceDTO.getIdreference());
        category.setIdreference(reference);

        //Foranea Size

        SizeDTO sizeDTO=categoryDTO.getIdsize();
        Size size= sizeService.findById(sizeDTO.getIdsize());
        category.setIdsize(size);


        category.setNamecategory(categoryDTO.getNamecategory());
        category.setDesccategory(categoryDTO.getDescategory());



        this.categoryService.create(category);
    }

    public void updateCategory(int id, CategoryDTO updatedCategoryDTO) throws Exception {
        Category existingCategory = categoryService.findById(id);
        if (existingCategory == null) {
            throw new Exception("Categoria no encontrada!");
        }

        existingCategory.setNamecategory(updatedCategoryDTO.getNamecategory());
        existingCategory.setDesccategory(updatedCategoryDTO.getDescategory());

        //Foranea Reference
        if (updatedCategoryDTO.getIdreference()!=null){
            int referenceId=updatedCategoryDTO.getIdreference().getIdreference();
            Reference reference=referenceService.findById(referenceId);
            if (reference==null){
                throw  new Exception("El id"+referenceId+"no se encuentra");

            }
            existingCategory.setIdreference(reference);
        }

        //Foranea Size
        if (updatedCategoryDTO.getIdsize()!=null){
            int sizeId=updatedCategoryDTO.getIdsize().getIdsize();
            Size size=sizeService.findById(sizeId);
            if (size==null){
                throw  new Exception("El id"+sizeId+"no se encuentra");

            }
            existingCategory.setIdsize(size);
        }


        this.categoryService.update(existingCategory);
    }

    public void deleteCategory(int id) throws Exception{
        Category  existingCategory = categoryService.findById(id);
        if (existingCategory== null) {
            throw new Exception("Categoria no encontrado!");
        }

        this.categoryService.delete(existingCategory);
    }
}
