package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;

@Entity
@Table(name = "request")
@Data


public class Request implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column (name = "idrequest")
    private int idrequest;

    @Column(name= "daterequest")
    private Date daterequest;
    @Column(name= "typerequest", length = 11)
    private String typerequest;
    @Column(name= "statusrequest", length = 25)
    private String statusrequest;
    @Column(name = "valuerequest")
    private float valuerequest;
 //Relacion foranea
    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name = "iduser")
    private User iduser;

    @JsonBackReference
    @OneToMany (mappedBy = "idrequest")
    private List<Sale> saleList;


}
