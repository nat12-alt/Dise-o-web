package com.example.demo.service.imp;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public  class Userimp implements UserService {


    @Autowired
    private UserRepository userRepository;

    @Override
    public List<User> findAll() {
        return this.userRepository.findAll();
    }

    @Override
    public User findById(int iduser) {

        User user= this.userRepository.findById(iduser);
        return user;
    }


    @Override
    public void create(User user) {
        this.userRepository.save(user);

    }

    @Override
    public void update(User user) {
        this.userRepository.save(user);

    }

    @Override
    public void delete(User user) {
        this.userRepository.delete(user);

    }


}

