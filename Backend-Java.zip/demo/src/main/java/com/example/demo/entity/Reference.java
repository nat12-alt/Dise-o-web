package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "referencs")
@Data
public class Reference implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idreference")
    private int idreference;

    @Column(name = "namereference", length = 25)
    private String namereference;

    //Foranea Reference
    @JsonBackReference
    @OneToMany (mappedBy = "idreference")
    private List<Category> categoryList;

}


