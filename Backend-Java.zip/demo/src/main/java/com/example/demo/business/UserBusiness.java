package com.example.demo.business;

import com.example.demo.DTO.CityDTO;
import com.example.demo.DTO.RoleDTO;
import com.example.demo.DTO.UserDTO;
import com.example.demo.entity.City;
import com.example.demo.entity.Role;
import com.example.demo.entity.User;
import com.example.demo.service.CityService;
import com.example.demo.service.RoleService;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class UserBusiness {

    @Autowired
    private UserService userService;
    @Autowired
    private CityService cityService;
    @Autowired
    private RoleService roleService;
    private List<User> userList;

    private List<UserDTO> userDTOList = new ArrayList<>();

    public List<UserDTO> findAll() {
        this.userList = this.userService.findAll();
        this.userList.stream().forEach(user -> {
            UserDTO userDTO = new UserDTO();
            userDTO.setIduser(user.getIduser());
            userDTO.setNameuser(user.getNameuser());
            userDTO.setLastnameuser(user.getLastnameuser());
            userDTO.setPhoneuser(user.getPhoneuser());
            userDTO.setEmailuser(user.getEmailuser());
            userDTO.setAddressuser(user.getAddressuser());
            userDTO.setDateofbirthuser(user.getDateofbirthuser());
            userDTO.setPassworduser(user.getPassworduser());

            City city=user.getIdcity();
                if (city !=null){
                    CityDTO cityDTO= new CityDTO();
                    cityDTO.setIdcity(city.getIdcity());
                    userDTO.setIdcity(cityDTO);

                    Role role=user.getIdrole();
                    if ( role!=null){
                        RoleDTO roleDTO= new RoleDTO();
                    roleDTO.setIdrole(role.getIdrole());
                    userDTO.setIdrole(roleDTO);
                    }
                }

            userDTOList.add(userDTO);
        });

        return this.userDTOList;
    }

    public User findById(int iduser) {
        return this.userService.findById(iduser);
    }

    public void createUser(UserDTO userDTO) throws Exception {
        User user= new User();
        System.out.printf("@@"+userDTO.toString());
//Foranea city
     CityDTO cityDTO=userDTO.getIdcity();
     City city= cityService.findById(cityDTO.getIdcity());
     user.setIdcity(city);

  //Foranea role

        RoleDTO roleDTO=userDTO.getIdrole();
        Role role= roleService.findById(roleDTO.getIdrole());
        user.setIdrole(role);

        user.setNameuser(userDTO.getNameuser());
        user.setLastnameuser(userDTO.getLastnameuser());
        user.setPhoneuser(userDTO.getPhoneuser());
        user.setEmailuser(userDTO.getEmailuser());
        user.setAddressuser(userDTO.getAddressuser());
        user.setDateofbirthuser(userDTO.getDateofbirthuser());
        user.setPassworduser(userDTO.getPassworduser());

        this.userService.create(user);
    }

    public void updateUser(int id, UserDTO updatedUSerDTO) throws Exception {
        User existingUser = userService.findById(id);
        if (existingUser == null) {
            throw new Exception("Usuario no encontrado!");
        }

        existingUser.setNameuser(updatedUSerDTO.getNameuser());
        existingUser.setLastnameuser(updatedUSerDTO.getLastnameuser());
        existingUser.setPhoneuser(updatedUSerDTO.getPhoneuser());
        existingUser.setEmailuser(updatedUSerDTO.getEmailuser());
        existingUser.setAddressuser(updatedUSerDTO.getAddressuser());
        existingUser.setDateofbirthuser(updatedUSerDTO.getDateofbirthuser());
        existingUser.setPassworduser(updatedUSerDTO.getPassworduser());

        //Foranea city
if (updatedUSerDTO.getIdcity()!=null){
    int cityId=updatedUSerDTO.getIdcity().getIdcity();
    City city=cityService.findById(cityId);
    if (city==null){
        throw  new Exception("El id"+cityId+"no se encuentra");
    }
    existingUser.setIdcity(city);
}
   //Foranea Role

        if (updatedUSerDTO.getIdrole()!=null){
            int roleId=updatedUSerDTO.getIdrole().getIdrole();
            Role role=roleService.findById(roleId);
            if (role==null){
                throw  new Exception("El id"+roleId+"no se encuentra");
            }
            existingUser.setIdrole(role);
        }

        this.userService.update(existingUser);
    }

    public void deleteUser(int id) throws Exception{
        User existingUser = userService.findById(id);
        if (existingUser == null) {
            throw new Exception("City no encontrado!");
        }

        this.userService.delete(existingUser);
    }
}
