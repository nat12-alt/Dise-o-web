package com.example.demo.business;


import com.example.demo.DTO.DealerDTO;
import com.example.demo.entity.Dealer;
import com.example.demo.service.DealerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
@Component
public class DealerBussines {
    @Autowired
    private DealerService  dealerService;

    private List<Dealer> dealerList;

    private List<DealerDTO> dealerDTOList = new ArrayList<>();

    public List<DealerDTO> findAll() {
        this.dealerList= this.dealerService.findAll();
        this.dealerList.stream().forEach(dealer -> {
            DealerDTO dealerDTO = new DealerDTO();
            dealerDTO.setIddealer(dealer.getIddealer());
            dealerDTO.setNamedealer(dealer.getNamedealer());
            dealerDTO.setAddressdealer(dealer.getAddressdealer());
            dealerDTO.setPhonedealer(dealer.getPhonedealer());


            dealerDTOList.add(dealerDTO);
        });
        return this.dealerDTOList;
    }

    public Dealer findById(int iddealer) {
        return this.dealerService.findById(iddealer);
    }

    public void createDealer(DealerDTO dealerDTO) throws Exception {
        Dealer dealer= new Dealer();
        //Concatenacion
        System.out.printf("@@"+dealerDTO.toString());

        dealer.setNamedealer(dealerDTO.getNamedealer());
        dealer.setAddressdealer(dealerDTO.getAddressdealer());
        dealer.setPhonedealer(dealerDTO.getPhonedealer());


        this.dealerService.create(dealer);
    }

    public void updateDealer (int id, DealerDTO updatedDealerDTO) throws Exception {
        Dealer existingDealer = dealerService.findById(id);
        if (existingDealer == null) {
            throw new Exception("Dealer no encontrado!");
        }

        existingDealer.setNamedealer(updatedDealerDTO.getNamedealer());
        existingDealer.setAddressdealer(updatedDealerDTO.getAddressdealer());
        existingDealer.setPhonedealer(updatedDealerDTO.getPhonedealer());

        this.dealerService.update(existingDealer);
    }

    public void deleteDealer(int id) throws Exception{
        Dealer existingDealer = dealerService.findById(id);
        if (existingDealer == null) {
            throw new Exception("Dealer no encontrado!");
        }

        this.dealerService.delete(existingDealer);
    }
}


