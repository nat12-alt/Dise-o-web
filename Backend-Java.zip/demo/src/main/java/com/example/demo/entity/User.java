package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;

@Entity
@Table (name="users")
@Data


public class User implements Serializable {
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    @Column (name = "iduser")
    private int iduser;

    @Column(name= "nameuser", length = 25)
    private String  nameuser;
    @Column(name= "lastnameuser", length = 25)
    private String lastnameuser;
    @Column(name= "phoneuser", length = 25)
    private double phoneuser;
    @Column(name= "emailuser", length = 25)
     private String emailuser;
    @Column(name= "addressuser", length = 25)
    private String addressuser;
    @Column(name= "dateofbirthuser")
    private Date dateofbirthuser;
    @Column(name= "passworduser")
    private String passworduser;

    //Relacion foranea
    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name = "idcity")
    private City idcity;

    //Relacion foranea
    @JsonManagedReference
    @OneToOne
    @JoinColumn(name = "idrole")
    private Role idrole;

    //Relacion foranea
    @JsonBackReference
    @OneToMany (mappedBy = "idrequest")
    private List<Request> requestList;
}
