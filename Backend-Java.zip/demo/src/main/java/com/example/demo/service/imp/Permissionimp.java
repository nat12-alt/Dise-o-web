package com.example.demo.service.imp;

import com.example.demo.entity.Permission;
import com.example.demo.repository.PermissionRepository;
import com.example.demo.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public  class Permissionimp implements PermissionService {
    @Autowired
    private PermissionRepository permissionRepository;

    @Override
    public List<Permission> findAll() {
        return this.permissionRepository.findAll();
    }

    @Override
    public Permission findById(int idpermission) {

        Permission permission= this.permissionRepository.findById(idpermission);
        return permission;
    }

    @Override
    public void create(Permission permission) {
        this.permissionRepository.save(permission);

    }

    @Override
    public void update(Permission permission) {
        this.permissionRepository.save(permission);

    }

    @Override
    public void delete(Permission permission) {
        this.permissionRepository.delete(permission);

    }
}