package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.util.List;


@Entity
@Table (name = "sizes")
@Data


public class Size implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column (name = "idsize")
    private int idsize;

    @Column(name= "numsize")
    private int numsize;

    @Column(name= "letersize")
    private String letersize;

   //Foranea Size
   @JsonBackReference
   @OneToMany (mappedBy = "idsize")
    private List<Category> categoryList;
}
