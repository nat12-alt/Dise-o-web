package com.example.demo.business;

import com.example.demo.DTO.CityDTO;
import com.example.demo.entity.City;
import com.example.demo.service.CityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
@Component
public class CityBussines {
    @Autowired
    private CityService cityService;

    private List<City> cityList;

    private List<CityDTO> cityDTOList = new ArrayList<>();

    public List<CityDTO> findAll() {
        this.cityList= this.cityService.findAll();
        this.cityList.stream().forEach(city -> {
            CityDTO cityDTO = new CityDTO();
            cityDTO.setIdcity(city.getIdcity());
            cityDTO.setNamecity(city.getNamecity());


            cityDTOList.add(cityDTO);
        });
        return this.cityDTOList;
    }

    public City findById(int idCity) {

        return this.cityService.findById(idCity);
    }

    public void createCity(CityDTO cityDTO) throws Exception {
        City city = new City();
        //Concatenacion
        System.out.printf("@@"+cityDTO.toString());

        city.setNamecity(cityDTO.getNamecity());

        this.cityService.create(city);
    }

    public void updateCity(int id, CityDTO updatedCityDTO) throws Exception {
        City existingCity = cityService.findById(id);
        if (existingCity == null) {
            throw new Exception("City no encontrado!");
        }

        existingCity.setNamecity(updatedCityDTO.getNamecity());

        this.cityService.update(existingCity);
    }

    public void deleteCity(int id) throws Exception{
        City existingCity = cityService.findById(id);
        if (existingCity == null) {
            throw new Exception("City no encontrado!");
        }

        this.cityService.delete(existingCity);
    }
}
