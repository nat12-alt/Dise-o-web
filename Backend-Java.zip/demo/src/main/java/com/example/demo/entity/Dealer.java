package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Table(name = "dealers")
@Data

public class Dealer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column (name = "iddealer")
    private  int iddealer;

    @Column(name= "namedealer", length = 11)
    private String namedealer;

    @Column(name= "addressdealer", length = 11)
    private String addressdealer;

    @Column(name= "phonedealer", length = 11)
    private double phonedealer;

    //ManyToMany para product_dealer
    @JsonBackReference
    @ManyToMany(mappedBy = "dealerList", fetch = FetchType.LAZY)
    private List<Product> productList;
}


