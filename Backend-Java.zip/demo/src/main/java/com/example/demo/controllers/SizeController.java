package com.example.demo.controllers;

import com.example.demo.DTO.SizeDTO;

import com.example.demo.business.SizeBusiness;


import com.example.demo.entity.Size;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Size", method = {RequestMethod.GET, RequestMethod.POST})
@CrossOrigin("*")
public class SizeController {

    @Autowired
    private SizeBusiness sizeBusiness;


    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllSize()  {
        Map<String, Object> res = new HashMap<>();
        List<SizeDTO> listSize = this.sizeBusiness.findAll();
        res.put("status", "success");
        res.put("data", listSize);

        return new ResponseEntity<>(res, HttpStatus.OK);
    }



    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getSizeById(@PathVariable int id) {
        try {
            Size data = sizeBusiness.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("status", "success");
            response.put("data", data);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("status", "error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}



