package com.example.demo.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DetailProductDTO {
    private int iddetailproduct;
    private  int entrycount ;
    private Date entrydate ;
    private String exittype;
    private  Date exitdate ;
    private  int exitcount ;
    private String typeexit;
 //Llave foraneas
    private SaleDTO idsale ;
    private ProductDTO idproduct;



}
