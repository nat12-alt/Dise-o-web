package com.example.demo.controllers;


import com.example.demo.DTO.CategoryDTO;

import com.example.demo.business.CategoryBussines;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Category",method = {RequestMethod.GET,RequestMethod.PUT,RequestMethod.POST})
@CrossOrigin("*")
public class CategoryCrontroller {
    @Autowired
    private CategoryBussines categoryBussines;

    @GetMapping("/all")
    public ResponseEntity<Map<String,Object>> findAllCategory() throws Exception {
        Map<String, Object> res = new HashMap<>();
        List<CategoryDTO> listCategoryDTO= this.categoryBussines.findAll();
        res.put( "status", "success");
        res.put("data", listCategoryDTO);

        return new ResponseEntity<>(res, HttpStatus.OK);

    }


    @PostMapping ("/create")
    public ResponseEntity<Map<String,Object>>createCategory(@RequestBody CategoryDTO newCategory) {
        Map<String, Object> response = new HashMap<>();

        try {
            categoryBussines.createCategory (newCategory);
            response.put("status", "Succes");
            response.put("data",newCategory);
            return new ResponseEntity<>(response,HttpStatus.OK);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("massage", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateCategory(@PathVariable int id, @RequestBody CategoryDTO existingCategory) {
        Map<String, Object> res = new HashMap<>();
        try {
            categoryBussines.updateCategory(id, existingCategory);
            res.put("status", "success");
            res.put("data", existingCategory);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteCategory(@PathVariable int id) {
        Map<String, Object> res = new HashMap<>();
        try {
            categoryBussines.deleteCategory(id);
            res.put("status", "success");
            res.put("message", "Buy deleted successfully");
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}

