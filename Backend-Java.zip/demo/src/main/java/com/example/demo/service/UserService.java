package com.example.demo.service;

import com.example.demo.entity.User;

import java.util.List;

public interface UserService {
    public List<User> findAll() ;

    public User findById (int iduser);

    public void create (User user);

    public void update (User user);

    public void delete (User user);

}
