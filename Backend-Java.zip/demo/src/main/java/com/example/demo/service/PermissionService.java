package com.example.demo.service;

import com.example.demo.entity.Permission;

import java.util.List;

public interface PermissionService {
    public List<Permission> findAll();
    public Permission findById(int idpermission);
    public void create (Permission permission);
    public void update (Permission permission);

    public void delete (Permission permission);
}
