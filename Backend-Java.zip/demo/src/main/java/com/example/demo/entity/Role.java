package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;

@Entity
@Table(name = "roles")
@Data
public class Role implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idrole")
    private int idrole ;

    @Column(name = "namerole", length = 25)
    private String namerole;
 //Relacion foranea
    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name = "idpermission")
    private Permission idpermission;
}
