package com.example.demo.service;

import com.example.demo.entity.Dealer;

import java.util.List;

public interface DealerService {
    public List<Dealer> findAll() ;

    Dealer findById(int iddealer);

    void create(Dealer dealer);

    void update(Dealer dealer);

    void delete(Dealer dealer);
}
