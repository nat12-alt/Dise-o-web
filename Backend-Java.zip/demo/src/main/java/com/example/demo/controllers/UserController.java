package com.example.demo.controllers;

import com.example.demo.DTO.UserDTO;
import com.example.demo.business.UserBusiness;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;



@RestController
@RequestMapping(path = "/api/User",method = {RequestMethod.GET,RequestMethod.PUT,RequestMethod.POST})
@CrossOrigin("*")
public class UserController {

    @Autowired
     private UserBusiness userBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String,Object>> findAllUser() throws Exception {
        Map<String, Object> res = new HashMap<>();
        List<UserDTO> listUserDto= this.userBusiness.findAll();
        res.put( "status", "success");
        res.put("data", listUserDto);

        return new ResponseEntity<>(res, HttpStatus.OK);

    }

    @PostMapping ("/create")
            public ResponseEntity<Map<String,Object>>createUser(@RequestBody UserDTO newUser) {
        Map<String, Object> response = new HashMap<>();

        try {
             userBusiness.createUser(newUser);
           response.put("status", "Succes");
           response.put("data",newUser);
           return new ResponseEntity<>(response,HttpStatus.OK);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("massage", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.OK);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateUser(@PathVariable int id, @RequestBody UserDTO existingUser
    ) {
        Map<String, Object> res = new HashMap<>();
        try {
            userBusiness.updateUser(id, existingUser);
            res.put("status", "success");
            res.put("data", existingUser);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);

        }
}
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteUser(@PathVariable int id) {
        Map<String, Object> res = new HashMap<>();
        try {
            userBusiness.deleteUser(id);
            res.put("status", "success");
            res.put("message", "Buy deleted successfully");
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}














