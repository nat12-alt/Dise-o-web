package com.example.demo.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategoryDTO {
    private int idcategory;
    private String namecategory;
    private  String descategory;
  //Llave foranea
    private ReferenceDTO idreference;
    private  SizeDTO idsize;

}
