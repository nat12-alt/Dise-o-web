package com.example.demo.business;


import com.example.demo.DTO.PermissionDTO;
import com.example.demo.DTO.RoleDTO;
import com.example.demo.entity.Permission;
import com.example.demo.entity.Role;
import com.example.demo.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class RoleBussines {

    @Autowired
    private RoleService roleService;

    private List<Role> roleList;

    private List<RoleDTO> roleDTOList = new ArrayList<>();

    public List<RoleDTO> findAll() {
        this.roleList= this.roleService.findAll();
        this.roleList.stream().forEach(role-> {
            RoleDTO roleDTO = new RoleDTO();
            roleDTO.setIdrole(role.getIdrole());
            roleDTO.setNamerole(role.getNamerole());


            //Foranea permisson

            Permission permission= role.getIdpermission();
            if (permission !=null) {
                PermissionDTO permissionDTO = new PermissionDTO();
                permissionDTO.setIdpermission(permission.getIdpermission());
                roleDTO.setIdpermission(permissionDTO);
            }

            roleDTOList.add(roleDTO);
        });
        return this.roleDTOList;
    }

    public Role findById(int idrole) {


        return this.roleService.findById(idrole);
    }


}