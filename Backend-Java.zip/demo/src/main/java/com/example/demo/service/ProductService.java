package com.example.demo.service;

import com.example.demo.entity.Product;


import java.util.List;

public interface ProductService {
    public List<Product> findAll() ;
    public Product findById(int idproduct);

    public void create (Product product);
    public void update (Product product);
    public void delete (Product product);



}
