package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "permission")
@Data
public class Permission implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idpermission")
    private int idpermission ;

    @Column(name = "typepermission")
    private String typepermission;

//Relacion de  foranea
    @JsonBackReference
    @OneToMany (mappedBy = "idpermission")
    private List<Role> roleList;

}


