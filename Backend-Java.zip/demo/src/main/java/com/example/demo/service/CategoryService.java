package com.example.demo.service;

import com.example.demo.entity.Category;


import java.util.List;

public interface CategoryService {
    public List<Category> findAll();
    public Category findById (int idcategory);
    public void create (Category category);
    public void  update (Category category);
    public void delete (Category category);


}
