package com.example.demo.controllers;

import com.example.demo.DTO.ProductDTO;
import com.example.demo.business.ProductBussines;
import com.example.demo.entity.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Product", method = { RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST })
@CrossOrigin("*")
public class ProductController {
    @Autowired
    private ProductBussines  productBussines;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllCity() {
        Map<String, Object> res = new HashMap<>();
        List<ProductDTO> listProduct= this.productBussines.findAll();
        res.put("status", "success");
        res.put("data", listProduct);

        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getProductById(@PathVariable int id) {
        try {
            Product data = productBussines.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("status", "success");
            response.put("data", data);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("status", "error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createProduct(@RequestBody  ProductDTO newProduct) {
        Map<String, Object> res = new HashMap<>();

        try {
            productBussines.createProduct(newProduct);
            res.put("status", "success");
            res.put("data", newProduct);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateProduct(@PathVariable int id, @RequestBody ProductDTO existingProduct) {
        Map<String, Object> res = new HashMap<>();
        try {
            productBussines.updateProduct(id, existingProduct);
            res.put("status", "success");
            res.put("data", existingProduct);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteProduct(@PathVariable int id) {
        Map<String, Object> res = new HashMap<>();
        try {
            productBussines.deleteProduct(id);
            res.put("status", "success");
            res.put("message", "Buy deleted successfully");
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}

