package com.example.demo.service;

import com.example.demo.entity.DetailProduct;


import java.util.List;

public interface DetailProductService {
    public List<DetailProduct> findAll() ;

    public DetailProduct findById (int iddetailproduct);
    public void create (DetailProduct detailProduct);
    public void  update (DetailProduct detailProduct);
    public void delete (DetailProduct detailProduct);


}
