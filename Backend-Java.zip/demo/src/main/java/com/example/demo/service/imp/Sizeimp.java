package com.example.demo.service.imp;


import com.example.demo.entity.Size;
import com.example.demo.repository.SizeRepository;
import com.example.demo.service.SizeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service

public class Sizeimp implements SizeService {
    @Autowired
    private SizeRepository sizeRepository;



    @Override
    public List<Size> findAll() {
        return this.sizeRepository.findAll();
    }

    @Override
    public Size findById(int idsize) {
        Size size= this.sizeRepository.findById(idsize);
        return size;

    }




}