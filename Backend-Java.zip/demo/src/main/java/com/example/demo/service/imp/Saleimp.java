package com.example.demo.service.imp;

import com.example.demo.entity.Sale;
import com.example.demo.repository.SaleRepository;
import com.example.demo.service.SaleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Saleimp implements SaleService {
    @Autowired
    private SaleRepository saleRepository;


    @Override
    public List<Sale>  findAll(){return this.saleRepository.findAll();}

    @Override
    public Sale findById(int idsale){
        Sale sale= this.saleRepository.findById(idsale);
        return sale;

    }

    @Override
    public void create(Sale sale){
        this.saleRepository.save(sale);

    }

    @Override
    public void update(Sale sale){
        this.saleRepository.save(sale);
    }

    @Override
    public void delete(Sale sale){
        this.saleRepository.delete(sale);
    }


}
