package com.example.demo.business;

import com.example.demo.DTO.DetailProductDTO;
import com.example.demo.DTO.ProductDTO;
import com.example.demo.DTO.SaleDTO;
import com.example.demo.entity.DetailProduct;
import com.example.demo.entity.Product;
import com.example.demo.entity.Sale;
import com.example.demo.service.DetailProductService;
import com.example.demo.service.ProductService;
import com.example.demo.service.SaleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DetailProductBussines {
    @Autowired
    private DetailProductService detailProductService;
    @Autowired
    private SaleService saleService;
    @Autowired
    private ProductService productService;
    private List<DetailProduct> detailProductList;

    private List<DetailProductDTO> detailProductDTOList = new ArrayList<>();

    public List<DetailProductDTO> findAll() {
        this.detailProductList= this.detailProductService.findAll();
        this.detailProductList.stream().forEach(detailProduct -> {
            DetailProductDTO detailProductDTO = new DetailProductDTO();
            detailProductDTO.setIddetailproduct(detailProduct.getIddetailproduct());
            detailProductDTO.setEntrycount(detailProduct.getEntrycount());
            detailProductDTO.setEntrydate(detailProduct.getEntrydate());
            detailProductDTO.setExittype(detailProduct.getExittype());
            detailProductDTO.setExitdate(detailProduct.getExitdate());
            detailProduct.setExitcount(detailProduct.getExitcount());

            //Foranea Sale
            Sale sale =detailProduct.getIdsale();
            if (sale !=null) {
                SaleDTO saleDTO = new SaleDTO();
                saleDTO.setIdsale(sale.getIdsale());
                detailProductDTO.setIdsale(saleDTO);
            }

            //Foranea Product
            Product product =detailProduct.getIdproduct();
            if (product !=null) {
                ProductDTO productDTO = new ProductDTO();
                productDTO.setIdproduct(product.getIdproduct());
                detailProductDTO.setIdproduct(productDTO);
            }
            detailProductDTOList.add(detailProductDTO);
        });
        return this.detailProductDTOList;
    }

    public DetailProduct findById(int idDetailProduct) {

        return this.detailProductService.findById(idDetailProduct);
    }

    public void createDetailProduct(DetailProductDTO detailProductDTO) throws Exception {
        DetailProduct detailProduct = new DetailProduct();
//Concatenacion
        System.out.printf("@@"+detailProductDTO.toString());
        //Foranea Sale
        SaleDTO  saleDTO=detailProductDTO.getIdsale();
        Sale sale= saleService.findById(saleDTO.getIdsale());
        detailProduct.setIdsale(sale);

        //Foranea Product
        ProductDTO productDTO=detailProductDTO.getIdproduct();
        Product product= productService.findById(productDTO.getIdproduct());
        detailProduct.setIdproduct(product);



        detailProduct.setEntrycount(detailProductDTO.getEntrycount());
        detailProduct.setEntrydate(detailProductDTO.getEntrydate());
        detailProduct.setExittype(detailProductDTO.getExittype());
        detailProduct.setExitdate(detailProductDTO.getExitdate());
        detailProduct.setEntrycount(detailProductDTO.getEntrycount());
        detailProduct.setExitcount(detailProductDTO.getExitcount());

        this.detailProductService.create(detailProduct);
    }

    public void updateDetailProduct(int id, DetailProductDTO updatedDetailProductDTO) throws Exception {
        DetailProduct existingDetailProduct = detailProductService.findById(id);
        if (existingDetailProduct == null) {
            throw new Exception("Detalle de producto no encontrado!");
        }

        existingDetailProduct.setEntrycount(updatedDetailProductDTO.getEntrycount());
        existingDetailProduct.setEntrydate(updatedDetailProductDTO.getEntrydate());
        existingDetailProduct.setExittype(updatedDetailProductDTO.getExittype());
        existingDetailProduct.setExitdate(updatedDetailProductDTO.getExitdate());
        existingDetailProduct.setEntrycount(updatedDetailProductDTO.getEntrycount());
        existingDetailProduct.setExitcount(updatedDetailProductDTO.getExitcount());

       //Foranea sale
        if (updatedDetailProductDTO.getIdsale()!=null){
            int saleId=updatedDetailProductDTO.getIdsale().getIdsale();
            Sale sale=saleService.findById(saleId);
            if (sale==null){
                throw  new Exception("El id"+saleId+"no se encuentra");

            }
            existingDetailProduct.setIdsale(sale);

        }
        //Foranea Product
        if (updatedDetailProductDTO.getIdproduct()!=null){
            int productId=updatedDetailProductDTO.getIdproduct().getIdproduct();
            Product product=productService.findById(productId);
            if (product==null){
                throw  new Exception("El id"+productId+"no se encuentra");

            }
            existingDetailProduct.setIdproduct(product);

        }
        this.detailProductService.update(existingDetailProduct);
    }

    public void deleteDetailProduct(int id) throws Exception{
        DetailProduct existingDetailProduct = detailProductService.findById(id);
        if (existingDetailProduct == null) {
            throw new Exception("Detalle producto no encontrado!");
        }

        this.detailProductService.delete(existingDetailProduct);
    }
}


